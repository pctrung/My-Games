#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define MAX 100

	// Doc ki tu
char readchar(){ 
	char ch;
	fflush(stdin);
	printf("\tWhat is the Sercet Word: ");
	scanf("%c",&ch);
	fflush(stdin);
	
	ch = toupper(ch);
	return ch;
}
	//reset lai gia tri
void reset(int* turn, int* flag, int* test, int* conti){
	*turn = 10;
	*flag = 0;
	*test = 0;
	*conti = 1;
	system("cls");
}

int main(){
	
	int i, len, turn = 10 , flag = 0, test = 0, conti = 1, random, numOfWord = 0;
	char input, testC;
	char suggest[200];
	
	// mo file, dem so dong
	FILE* sourc = NULL;
	sourc = fopen("SOURCE WORD.txt", "r");
	if(sourc == NULL)
		return 0;
	do{
		testC = fgetc(sourc);
		if(testC == '\n')
			numOfWord ++;
	}while(testC != EOF);
		printf("%d", numOfWord);
	
	while(conti != 0){
		char* secretWord;
		
		if(turn == 0) break;
		rewind(sourc);
		printf("\t\t=== WELCOME TO THE LETTERING GAME ===\t\t");
		
		// random tu bi an
		do {
			srand(time(NULL));
			random = (rand() % numOfWord);
		}while(random % 2 != 1);
		printf("%d", random);
		
		// gan tu bi mat cho con tro
		char secret[MAX];
		for(i = 1; i <= random; i++)
			fgets(secret, MAX, sourc);
		fgets(suggest, 200, sourc);
		len = strlen(secret);
		secret[len-1] = '\0';
		len = strlen(secret);
		secretWord = strdup(secret);
		
		printf("\n\n\tSecret Word include %d characters.\n", len);
		printf("\tSUGGESTIONE: %s", suggest);
		
		for(i = 0; i < len; i++)		//dat dau sao
			secretWord[i] = '*';
			
		while(turn > 0){				//lap lai khi chua doan xong
			
			input = readchar();
		
			for(i = 0; i < len; i++){
				if (secret[i] == input){
					secretWord[i] = input;
					flag ++;
				}
			}
			// kiem tra dung sai
			if(flag == 0){
				turn --;
				if(turn == 0){
					printf("\n\n\nGAME OVER!!!\n\n\n");
					printf("Do you want to continue ?\n\n\nPress ANY NUMER to CONTINUE, 0 to STOP: ");
					scanf("%d",&turn);
					if(turn != 0)
						reset(&turn, &flag, &test, &conti);
					break;	
				}
				printf("\nWrong character. Please try again!\nYou have %d guess.\n",turn);
				printf("Secret Word: %s \n\n\n", secretWord);
			}
			else if(flag != 0){
				printf("\nGuess exactly %d character!\nYou have %d guess.\n", flag, turn);
				printf("Secret Word: %s \n\n\n", secretWord);
				flag = 0;
				if(strcmp(secretWord, secret) == 0){
					printf("YOU WON!!!\n\n\n");
					printf("Do you want to continue ?\n\n\nPress ANY NUMER to CONTINUE, 0 to STOP: ");
					scanf("%d",&turn);  
					if(turn != 0){
						reset(&turn, &flag, &test, &conti);
						break;	
					}
				}
			}	
		}
		free(secretWord);
	}
	fclose(sourc);
	
	return 0;
}
