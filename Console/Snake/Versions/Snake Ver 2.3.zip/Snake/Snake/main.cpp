#include <stdio.h>
#include "console.h"
#include <Windows.h>
#include <conio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <iostream>
using namespace std;

#define ColorWall	ColorCode_DarkCyan
#define ColorSnake	ColorCode_Green
#define ColorFruit	ColorCode_Yellow
#define ColorTable	ColorCode_Red
#define ColorScoreN	ColorCode_White

#define Width		80
#define	Hight		20

#define Head		233
#define Body		111
#define Fruit		232	
#define WallTop		220
#define WallBottom	223
#define WallEdge	219

enum Status {UP, DOWN, LEFT, RIGHT};
enum Level {EASY = 30, NORMAL = 35, HARD = 40};

void hidePointer(){
	HANDLE hOut;
	CONSOLE_CURSOR_INFO ConCurInf;
	hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	ConCurInf.dwSize = 10;
	ConCurInf.bVisible = FALSE;
	SetConsoleCursorInfo(hOut, &ConCurInf);
}

struct toado {
	int x, y;
};

struct snake {
	toado dot[100];
	int n;
	Status sta;
};

struct fruit {
	toado toado;
};

void createSnake(snake &snake, fruit &fruit) {
	snake.n = 5;
	for (int i = snake.n -1, j = 2; i >= 0; i--, j++) {
		snake.dot[i].x = j;
		snake.dot[i].y = 2;
	}
	
	snake.sta = RIGHT;
	while (1) {
		fruit.toado.x = rand() % (Width - 3);
		fruit.toado.y = rand() % (Hight - 3);
		if (fruit.toado.x != 0 && fruit.toado.y != 0)
			break;
	}
}

void displayInfo(int n, Level level) {

	TextColor(ColorTable);
	gotoXY(Width + 3, 1);
	printf("LEVEL: ");

	if (level == EASY) {
		TextColor(ColorCode_Green);
		puts("EASY");
	}
	else if (level == NORMAL) {
		TextColor(ColorCode_Yellow);
		puts("NORMAL");
	}
	else if (level == HARD) {
		TextColor(ColorCode_Red);
		puts("HARD");
	}

	TextColor(ColorTable);
	gotoXY(Width + 3, 3);
	printf("SCORE: ");

	TextColor(ColorScoreN);
	printf("%d", n - 5);
}

void displayOver(int over) {
	if (over == -1) {
		gotoXY((Width / 2) - 10, Hight / 2);
		puts("GAME OVER !!!");
	}
	else if (over == 1) {
		gotoXY((Width / 2) - 10, Hight / 2);
		puts("YOU WON !!!");
	}
}

void display(snake snake, fruit fruit, Level level) {

	displayInfo(snake.n, level);

	TextColor(ColorFruit);
	gotoXY(fruit.toado.x, fruit.toado.y);
	putchar(Fruit);

	TextColor(ColorSnake);
	gotoXY(snake.dot[0].x, snake.dot[0].y);
		putchar(Head);
	for (int i = 1; i < snake.n; i++) {
		gotoXY(snake.dot[i].x, snake.dot[i].y);
			putchar(Body);
	}
	gotoXY(snake.dot[snake.n - 1].x, snake.dot[snake.n - 1].y);
		putchar(' ');
	
}
// paint wall;
void displayWall() {
	TextColor(ColorWall);
	for (int i = 0; i <= Hight; i++) {
		gotoXY(Width, i);
		putchar(WallEdge);
		gotoXY(0, i);
		putchar(WallEdge);
	}
	for (int i = 0; i <= Width; i++) {
		gotoXY(i, 0);
		putchar(WallTop);
		gotoXY(i, Hight);
		putchar(WallBottom);
	}
}

void controlMove(snake &snake,fruit &fruit) {
	for (int i = snake.n - 1; i > 0; i--)
		snake.dot[i] = snake.dot[i - 1];

	if (_kbhit()) {
		int key = _getch();
		
		if ((key == 'w' || key == 'W' || key == 72 )&& snake.sta != DOWN)
			snake.sta = UP;
		else if ((key == 's' || key == 'S' || key == 80) && snake.sta != UP)
			snake.sta = DOWN;
		else if ((key == 'd' || key == 'D' || key == 77) && snake.sta != LEFT)
			snake.sta = RIGHT;
		else if ((key == 'a' || key == 'A' || key == 75) && snake.sta != RIGHT)
			snake.sta = LEFT;
	}
		if (snake.sta == UP)
			snake.dot[0].y--;
		else if(snake.sta == DOWN)
			snake.dot[0].y++;
		else if (snake.sta == LEFT)
			snake.dot[0].x--;
		else if (snake.sta == RIGHT)
			snake.dot[0].x++;
}

int handling(snake &snake, fruit &fruit, int &time, Level level) {
	if (snake.dot[0].x == fruit.toado.x && snake.dot[0].y == fruit.toado.y) {
		snake.n++;

		for (int i = snake.n - 1; i > 0; i--)
			snake.dot[i] = snake.dot[i - 1];
		if (snake.sta == UP)
			snake.dot[0].y--;
		else if (snake.sta == DOWN)
			snake.dot[0].y++;
		else if (snake.sta == LEFT)
			snake.dot[0].x--;
		else if (snake.sta == RIGHT)
			snake.dot[0].x++;

		while (1) {
			fruit.toado.x = rand() % (Width - 3);
			fruit.toado.y = rand() % (Hight - 3);
			if (fruit.toado.x != 0 && fruit.toado.y != 0)
				break;
		}
		time -= 2;
	}

	if (snake.dot[0].x <= 0 || snake.dot[0].x >= Width || snake.dot[0].y >= Hight || snake.dot[0].y <=  0)
		return -1;
	for (int i = 1; i < snake.n; i++) {
		if (snake.dot[0].x == snake.dot[i].x && snake.dot[0].y == snake.dot[i].y)
			return -1;
	}

	if (snake.n == level)
		return 1;

	return 0;
}

void randomize()
{
	srand((unsigned int)time(0));
}

int Menu(int &choose, int option, int len) {
	int key = 0;
	int leng = len + 5;
	while (key != 13) {
		for (int i = 0; i <= option * 2; i += 2){
			gotoXY(Width / 2 - leng, Hight / 2 - 4 + i);
			cout << ' ';
		}

		if ((key == 'w' || key == 'W' || key == 72) && choose != 1 && choose <= option)
			choose--;
		else if ((key == 's' || key == 'S' || key == 80) && choose != 3 && choose <= option)
			choose++;

		for (int i = 0; i <= option * 2; i += 2) {
			if (choose == i / 2 + 1) {
				gotoXY(Width / 2 - leng, Hight / 2 - 4 + i);
				putchar(175);
			}
		}
		key = _getch();
	}
	return choose;
}

int main() {
	int over, choose = 1;
	int time = 100;
	hidePointer();
	Level level = EASY;
	snake snake;
	fruit fruit;
	int len = 5;

	while (choose != 0) {
		choose = 1;

		displayWall();

		gotoXY(Width / 2 - len, Hight / 2 -4);
		puts("NEW GAME");
		gotoXY(Width / 2 - len, Hight / 2 -4 +2);
		puts("LEVEL");
		gotoXY(Width / 2 - len, Hight / 2 -4 +4);
		puts("EXIT");
		choose = Menu(choose, 3, len);
		switch(choose) {
			case 1: 
				createSnake(snake, fruit);
				break;
			case 2:
				choose = 1;
				clrscr();
				displayWall();
				gotoXY(Width / 2 - len, Hight / 2 - 4);
				puts("EASY");
				gotoXY(Width / 2 - len, Hight / 2 - 4 + 2);
				puts("NORMAL");
				gotoXY(Width / 2 - len, Hight / 2 - 4 + 4);
				puts("HARD");
				gotoXY(Width / 2 - len, Hight / 2 - 4 + 6);
				choose = Menu(choose, 3, len);

				switch(choose) {
					
					case 1: 
						level = EASY;
						time = 100;
						clrscr();
						break;
					case 2:
						level = NORMAL;
						time = 70;
						clrscr();
						break;
					case 3:
						level = HARD;
						time = 50;
						clrscr();
						break;
				}
				continue;
			case 3:
				gotoXY(Width / 2 - 10, Hight / 2 - 4 + 12);
				printf("EXIT GAME....");
				_getch();
				break;
		}
		if (choose == 0)
			break;
		clrscr();
		displayWall();
		randomize();

		while (1) {

			// display
			display(snake, fruit, level);
			// move
			controlMove(snake, fruit);
			// handling
			over = handling(snake, fruit, time, level);
			if (over == -1 || over == 1) {
				displayOver(over);
				while (_getch() != 13);
				clrscr();
				break;
			}
			if (snake.sta == UP || snake.sta == DOWN)
				Sleep(time + 80);
			else Sleep(time);
		}
	}
	return 0;
}