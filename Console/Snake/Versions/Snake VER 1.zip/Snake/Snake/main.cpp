#include <stdio.h>
#include "console.h"
#include <Windows.h>
#include <conio.h>
#include <time.h>
#include <ctype.h>

#define Width	35
#define	Hight	20

enum Status {UP, DOWN, LEFT, RIGHT};

void ancontro()
{
	HANDLE hOut;
	CONSOLE_CURSOR_INFO ConCurInf;
	hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	ConCurInf.dwSize = 10;
	ConCurInf.bVisible = FALSE;
	SetConsoleCursorInfo(hOut, &ConCurInf);
}

struct toado {
	int x, y;
};

struct snake {
	toado dot[31];
	int n;
	Status sta = RIGHT;
};

struct fruit {
	toado toado;
};

void createSnake(snake &snake, fruit &fruit) {
	snake.dot[0].x = 2;
	snake.dot[0].y = 2;
	snake.n = 1;
	while (1) {
		fruit.toado.x = rand() % (Width - 3);
		fruit.toado.y = rand() % (Hight - 3);
		if (fruit.toado.x != 0 && fruit.toado.y != 0)
			break;
	}
}

void display(snake snake, fruit fruit) {
	clrscr();

// paint wall;
	for (int i = 0; i <= Hight; i++) {
		gotoXY(Width, i);
			putchar(219);
		gotoXY(0, i);
			putchar(219);
	}
	for (int i = 0; i <= Width; i++) {
		gotoXY(i, 0);
			putchar(220);
		gotoXY(i, Hight);
			putchar(223);
	}

	gotoXY(fruit.toado.x, fruit.toado.y);
	putchar(232);

	gotoXY(snake.dot[0].x, snake.dot[0].y);
		putchar(233);
	for (int i = 1; i < snake.n; i++) {
		gotoXY(snake.dot[i].x, snake.dot[i].y);
			putchar('o');
	}

}
void controlMove(snake &snake,fruit &fruit) {

	for (int i = snake.n - 1; i > 0; i--)
		snake.dot[i] = snake.dot[i - 1];

	if (_kbhit()) {
		int key = _getch();
		key = tolower(key);
		if (key == 'w')
			snake.sta = UP;
		else if (key == 's')
			snake.sta = DOWN;
		else if (key == 'd')
			snake.sta = RIGHT;
		else if (key == 'a')
			snake.sta = LEFT;
	}

		if (snake.sta == UP)
			snake.dot[0].y--;
		else if(snake.sta == DOWN)
			snake.dot[0].y++;
		else if (snake.sta == LEFT)
			snake.dot[0].x--;
		else if (snake.sta == RIGHT)
			snake.dot[0].x++;

}

int handling(snake &snake, fruit &fruit, int &time) {
	if (snake.dot[0].x == fruit.toado.x && snake.dot[0].y == fruit.toado.y) {
		snake.n++;
		while (1) {
			fruit.toado.x = rand() % (Width - 3);
			fruit.toado.y = rand() % (Hight - 3);
			if (fruit.toado.x != 0 && fruit.toado.y != 0)
				break;
		}
		time -= 30;
	}
	if (snake.dot[0].x <= 0 || snake.dot[0].x >= 35 || snake.dot[0].y >= 20 || snake.dot[0].y <=  0)
		return -1;
	if (snake.n == 25)
		return 1;
	return 0;
}

int main() {

	srand((unsigned int)time(NULL));

	ancontro();

	snake snake;
	fruit fruit;
	
	createSnake(snake, fruit);
	int over;
	int time = 400;

	while (1) {
		// display
		display(snake, fruit);
		// move
		controlMove(snake, fruit);
		// handling
		over = handling(snake, fruit, time);
		if (over == -1) {
			gotoXY(12, 10);
			printf("THUA CMNR !!!");
			while (_getch() != 13);
			break;
		}
		else if (over == 1) {
			gotoXY(12, 10);
			printf("CHOI HAY ROI DO !!!");
			while (_getch() != 13);
			break;
		}

		Sleep(time);
	}
	return 0;
}